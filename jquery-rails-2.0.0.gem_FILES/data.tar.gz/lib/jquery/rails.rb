module Jquery
  module Rails
    PROTOTYPE_JS = %w{prototype effects dragdrop controls}

    require 'jquery/rails/engine'
    require 'jquery/rails/version'
  end
end
