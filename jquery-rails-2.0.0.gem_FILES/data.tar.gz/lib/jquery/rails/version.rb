module Jquery
  module Rails
    VERSION = "2.0.0"
    JQUERY_VERSION = "1.7.1"
    JQUERY_UI_VERSION  = "1.8.16"
    JQUERY_UJS_VERSION = "82292010fb1743f038ab72b1f1e994e91be3eda3"
  end
end
