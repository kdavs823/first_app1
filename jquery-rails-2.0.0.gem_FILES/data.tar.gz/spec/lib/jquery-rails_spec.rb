require 'spec_helper'

it "should probably test something, but I'm damned if I know what"